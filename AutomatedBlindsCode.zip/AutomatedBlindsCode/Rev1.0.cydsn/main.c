//AutoBlinds Rev 4.2
//Max Edward
//4/22/23
        
#include "project.h"
#include "stdio.h"

float photoVal, volts = 0;
float maxV = 300.00;
float minV = 150.00;
char b[15]={'\0'};

int gsteps = 0; 
int rsteps = 0;

int main(void) {
    
    float motorVelocity = 15; //revolutions per minute
    int motorSteps = 2048; //steps for motor to go 1 revolution
    int delay;
    delay = motorSteps/(60*motorVelocity); //formula for deriving delay from motorVelocity
    //int direction = -1; // 1 = clockwise, -1 = counter clockwise
    
    CyGlobalIntEnable;
    
    ADC_Start();
    LCD_Start();
    
    LCD_ClearDisplay();
    
    for(;;) {
        ADC_StartConvert();
    
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        
        photoVal = ADC_GetResult16(0);
        
        float32 volts = ADC_CountsTo_mVolts(0,photoVal);
        
        LCD_Position(0,0);
        
        LCD_PrintNumber((uint32)volts);
        
        LCD_PrintString("mV");
        
        if (volts > maxV) {
            if (gsteps < 2048) {
                rsteps = 0;
                for (; gsteps < 2048; gsteps++) {
                    Green_LED_Write(1);
                    A_Write(1);
                    B_Write(0);
                    C_Write(0);
                    D_Write(0);
                    CyDelay(delay);
                    
                    A_Write(0);
                    B_Write(1);
                    C_Write(0);
                    D_Write(0);
                    CyDelay(delay);
                    
                    A_Write(0);
                    B_Write(0);
                    C_Write(1);
                    D_Write(0);
                    CyDelay(delay);
                    
                    A_Write(0);
                    B_Write(0);
                    C_Write(0);
                    D_Write(1);
                    CyDelay(delay);
                    
                    LCD_Position(0,7);
        
                    LCD_PrintNumber((uint32)gsteps);
                    
                    LCD_PrintString("GStep Val");
                }
            }
        }
        if (volts < maxV && volts > minV) {
            Yellow_LED_Write(1);
        }
        if (volts < minV) {
            if (rsteps < 2048) {  
                gsteps = 0;
                for (; rsteps < 2048; rsteps++) {
                    Red_LED_Write(1);
                    A_Write(0);
                    B_Write(0);
                    C_Write(0);
                    D_Write(1);
                    CyDelay(delay);
                    
                    A_Write(0);
                    B_Write(0);
                    C_Write(1);
                    D_Write(0);
                    CyDelay(delay);
                    
                    A_Write(0);
                    B_Write(1);
                    C_Write(0);
                    D_Write(0);
                    CyDelay(delay);
                    
                    A_Write(1);
                    B_Write(0);
                    C_Write(0);
                    D_Write(0);
                    CyDelay(delay);
                    
                    LCD_Position(1,7);
        
                    LCD_PrintNumber((uint32)rsteps);
                    
                    LCD_PrintString("RStep Val");
                }
            }
        }
        
        Red_LED_Write(0);
        Yellow_LED_Write(0);
        Green_LED_Write(0);
    }
    
    LCD_ClearDisplay();
    
    CyDelay(100);
}